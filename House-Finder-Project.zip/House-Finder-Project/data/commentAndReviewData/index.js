/*
 * @Descripttion: 
 * @version: 
 * @Author: sueRimn
 * @Date: 2020-08-11 19:54:39
 * @LastEditors: Yiqun Peng
 * @LastEditTime: 2020-08-12 23:02:59
 */
const commentDataObj = require("./comments");
const reviewDataObj = require("./reviews");

module.exports = { 
    commentsData: commentDataObj,
    reviewsDate: reviewDataObj
};

