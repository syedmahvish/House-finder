const houseDataObj = require("./house");
const favHouseDataObj = require("./favourite");

module.exports = { houseData: houseDataObj, favHouseData: favHouseDataObj };
